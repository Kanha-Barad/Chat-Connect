import 'package:flutter/material.dart';

const String ENGLISH = 'en';
const String ARABIC = 'ar';

Locale setLocale(String languageCode) {
  return Locale(languageCode, '');
}
