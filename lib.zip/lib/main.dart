import 'dart:io' show Platform;
// import 'package:chatconect/services/web_FCM_Service.dart';
import 'package:flutter/foundation.dart';
import 'package:permission_handler/permission_handler.dart';
// import 'services/web_fcm_service_stub.dart'
// if (dart.library.html) 'services/web_fcm_service.dart';

import 'dart:html' as html;



import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
// import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'firebase_options.dart';
import 'services/notification_service.dart';
import 'utils/theme.dart';
import 'view model/auth_view_model.dart';
import 'view/bottom_nav_screen.dart';
import 'view/login_or_register.dart';
import 'view/splash_Screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  print("🟢 WidgetsFlutterBinding initialized");

  await EasyLocalization.ensureInitialized();
  print("🟢 EasyLocalization initialized");

  if (!kIsWeb && Platform.isAndroid) {
    final status = await Permission.notification.request();
    print("🔐 Android notification permission: $status");
  }

  final prefs = await SharedPreferences.getInstance();
  print("🟢 SharedPreferences loaded");

  final savedLocaleCode = prefs.getString('selectedLocale');
  final startLocale =
  savedLocaleCode != null ? Locale(savedLocaleCode) : const Locale('en');

  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  print("🟢 Firebase initialized");

  if (!kIsWeb)
  await NotificationService.initialize();
  print("🟢 NotificationService initialized");

  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  print("🟢 Background message handler registered");

  await initPushNotifications();
  print("🟢 initPushNotifications complete");
  runApp(
    EasyLocalization(
      supportedLocales: const [Locale('en'), Locale('hi'), Locale('ar')],
      path: 'assets/lang',
      startLocale: startLocale,
      fallbackLocale: const Locale('en'),
      child: const MyApp(),
    ),
  );
}

Future<void> initPushNotifications() async {
  FirebaseMessaging messaging = FirebaseMessaging.instance;
  if (kIsWeb) {
    // Register service worker explicitly
    await html.window.navigator.serviceWorker
        ?.register('firebase-messaging-sw.js');
    // Request notification permissions (optional — some browsers auto-handle it)
    await messaging.requestPermission();

    // Web push using VAPID key
    String? fcmToken = await messaging.getToken(
      vapidKey:
      'BIsbavOUcGWhPZmmUiwCjPh1m4XekWYNLPU-JHiB3zD3OanJW46XHFCZiHefqGrDchIQm8n6sDSmuWECfhDz6S4',
    );

    print('🌐 Web FCM Token: $fcmToken');

    // Handle foreground messages
    FirebaseMessaging.onMessage.listen((message) {
      print('📩 Web foreground message: ${message.notification?.title}');
    });
  }


  // if (kIsWeb) {
  //   await registerWebServiceWorker(messaging);
  //   return;
  // }

  if (!kIsWeb && Platform.isIOS) {
    await messaging.requestPermission();

    String? apnsToken;
    int retries = 0;
    while (apnsToken == null && retries < 10) {
      await Future.delayed(Duration(seconds: 1));
      apnsToken = await messaging.getAPNSToken();
      retries++;
    }

    if (apnsToken != null) {
      print('📱 APNs Token: $apnsToken');
    } else {
      print('⚠️ Failed to get APNs token');
    }

    String? fcmToken = await messaging.getToken();
    print('📱 iOS FCM Token: $fcmToken');
    return;
  }

  if (!kIsWeb && Platform.isAndroid) {
    String? fcmToken = await messaging.getToken();
    print('🤖 Android FCM Token: $fcmToken');
    return;
  }

  print('❌ Unsupported platform for push notifications');
}

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  print("🔕 Background message received: ${message.messageId}");
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthViewModel()),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        navigatorKey: navigatorKey,
        theme: lightMode,
        localizationsDelegates: context.localizationDelegates,
        supportedLocales: context.supportedLocales,
        locale: context.locale,
        home: RootScreen(),
      ),
    );
  }
}

class RootScreen extends StatefulWidget {
  const RootScreen({super.key});

  @override
  State<RootScreen> createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  bool? isLoggedIn;
  bool showSplash = true;

  @override
  void initState() {
    super.initState();

    Future.delayed(const Duration(seconds: 2), () {
      setState(() {
        showSplash = false;
      });
      checkLoginStatus();
    });
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      final notification = message.notification;
      if (notification != null && mounted) {
        // ScaffoldMessenger.of(context).showSnackBar(
        //   SnackBar(
        //     content:
        //         Text('${notification.title ?? ''}: ${notification.body ?? ''}'),
        //   ),
        // );
      }
    });
  }

  Future<void> checkLoginStatus() async {
    final authProvider = Provider.of<AuthViewModel>(context, listen: false);
    final loggedIn = await authProvider.isLoggedIn();
    setState(() {
      isLoggedIn = loggedIn;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (showSplash) {
      return const SplashScreen();
    }

    if (isLoggedIn == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return isLoggedIn!
        ? BottomNavScreen(
            currentUserId:
                Provider.of<AuthViewModel>(context, listen: false).user!.uid,
          )
        : const LoginOrRegisterScreen();
  }
}
