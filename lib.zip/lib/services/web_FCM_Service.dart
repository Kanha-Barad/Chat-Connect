// lib/services/web_fcm_service.dart
import 'dart:html' as html;
import 'package:firebase_messaging/firebase_messaging.dart';

Future<void> registerWebServiceWorker(FirebaseMessaging messaging) async {
  // Register service worker
  await html.window.navigator.serviceWorker
      ?.register('firebase-messaging-sw.js');

  // Request permission
  await messaging.requestPermission();

  // Get token with VAPID key
  String? fcmToken = await messaging.getToken(
    vapidKey:
    'BIsbavOUcGWhPZmmUiwCjPh1m4XekWYNLPU-JHiB3zD3OanJW46XHFCZiHefqGrDchIQm8n6sDSmuWECfhDz6S4',
  );
  print('🌐 Web FCM Token: $fcmToken');

  // Handle foreground messages
  FirebaseMessaging.onMessage.listen((message) {
    print('📩 Web foreground message: ${message.notification?.title}');
  });
}
