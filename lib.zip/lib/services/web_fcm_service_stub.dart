// lib/services/web_fcm_service_stub.dart
import 'package:firebase_messaging/firebase_messaging.dart';

Future<void> registerWebServiceWorker(FirebaseMessaging messaging) async {
  // No-op for mobile or desktop
  print('🛑 registerWebServiceWorker is not used on this platform.');
}